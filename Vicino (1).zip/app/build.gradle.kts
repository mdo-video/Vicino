plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Numero progressivo della build su GitHub: fa crescere versionCode a ogni compilazione,
// cosi' Android accetta l'aggiornamento sopra la versione gia' installata.
val runNumber = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 0

android {
    namespace = "com.vicino"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vicino"
        minSdk = 26
        targetSdk = 34
        versionCode = 100 + runNumber
        versionName = "1.$runNumber"
    }

    // Chiave di firma FISSA (app/vicino.p12): stessa firma a ogni build,
    // cosi' gli aggiornamenti si installano senza disinstallare.
    signingConfigs {
        create("fixed") {
            storeFile = file("vicino.p12")
            storeType = "pkcs12"
            storePassword = "vicino"
            keyAlias = "vicino"
            keyPassword = "vicino"
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("fixed")
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.dynamicanimation:dynamicanimation:1.0.0")
}
