package com.vicino

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat

/** Un dispositivo Bluetooth visto (o associato) con il suo segnale filtrato. */
class Dev(val address: String) {
    var name: String? = null
    var saved: Boolean = false
    var lastSeen: Long = 0L
    var smooth: Float? = null
    var distance: Float? = null
    var inRange: Boolean = false

    /** Segnale (dBm) misurato a 1 metro: se il dispositivo dichiara la potenza lo ricaviamo, altrimenti valore tipico. */
    var refRssi: Int = DEFAULT_REF

    private val samples = ArrayList<LongArray>() // [istante, rssi]

    fun addSample(t: Long, rssi: Int) {
        samples.add(longArrayOf(t, rssi.toLong()))
        lastSeen = t
        if (samples.size > 40) samples.removeAt(0)
    }

    /** Mediana degli ultimi secondi + media mobile: il segnale radio e' molto "rumoroso". */
    fun update(now: Long) {
        samples.removeAll { now - it[0] > WINDOW_MS }
        inRange = lastSeen != 0L && now - lastSeen < LOST_MS
        if (samples.isNotEmpty()) {
            val sorted = samples.map { it[1] }.sorted()
            val med = sorted[sorted.size / 2].toFloat()
            val prev = smooth
            smooth = if (prev == null) med else prev + 0.35f * (med - prev)
        }
        val s = smooth
        if (s != null) distance = rssiToDistance(s, refRssi)
    }

    companion object {
        const val DEFAULT_REF = -59
        const val WINDOW_MS = 6000L
        const val LOST_MS = 10000L

        /** Modello "path loss": d = 10^((rssi@1m - rssi) / (10 * n)), con n = 2,4 (ambienti chiusi). */
        fun rssiToDistance(rssi: Float, ref: Int): Float {
            val d = Math.pow(10.0, (ref - rssi) / (10.0 * 2.4))
            return d.toFloat().coerceIn(0.1f, 40f)
        }
    }
}

/**
 * Cuore dell'app: scansione Bluetooth (BLE + classico) condivisa tra le schermate.
 * Tutto gira sul thread principale (le callback del Bluetooth arrivano li').
 */
@SuppressLint("MissingPermission")
object ScanHub {

    private const val FORGET_MS = 30000L

    val devices = LinkedHashMap<String, Dev>()

    var scanning: Boolean = false
        private set
    var enabled: Boolean = false
        private set
    var error: String? = null
        private set

    private var appCtx: Context? = null
    private var attached = 0
    private var tickN = 0
    private var leScanner: BluetoothLeScanner? = null
    private val handler = Handler(Looper.getMainLooper())
    private val listeners = ArrayList<() -> Unit>()

    fun init(ctx: Context) {
        if (appCtx != null) return
        val app = ctx.applicationContext
        appCtx = app
        val f = IntentFilter()
        f.addAction(BluetoothDevice.ACTION_FOUND)
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        f.addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        f.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
        ContextCompat.registerReceiver(app, receiver, f, ContextCompat.RECEIVER_EXPORTED)
    }

    // ---------- permessi e stato del Bluetooth ----------

    fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

    fun hasScanPerm(): Boolean {
        val app = appCtx ?: return false
        return requiredPermissions().all {
            ContextCompat.checkSelfPermission(app, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun hasConnectPerm(): Boolean {
        val app = appCtx ?: return false
        return Build.VERSION.SDK_INT < 31 ||
            ContextCompat.checkSelfPermission(app, Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun adapter(): BluetoothAdapter? =
        (appCtx?.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    fun btOn(): Boolean = try {
        adapter()?.isEnabled == true
    } catch (e: SecurityException) {
        false
    }

    // ---------- ascoltatori e ciclo di vita ----------

    fun addListener(l: () -> Unit) {
        if (!listeners.contains(l)) listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    private fun notifyListeners() {
        for (l in ArrayList(listeners)) l()
    }

    /** Ogni schermata visibile chiama attach() in onStart e detach() in onStop. */
    fun attach() {
        attached++
        reconcile()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    fun detach() {
        attached = (attached - 1).coerceAtLeast(0)
        reconcile()
        if (attached == 0) handler.removeCallbacks(tick)
    }

    /** Volonta' dell'utente: cerca / ferma. */
    fun enable(on: Boolean) {
        enabled = on
        reconcile()
    }

    /** La ricerca gira solo se: l'utente la vuole, c'e' una schermata visibile, ci sono i permessi e il Bluetooth e' acceso. */
    fun reconcile() {
        val want = enabled && attached > 0 && hasScanPerm() && btOn()
        if (want && !scanning) startInternal() else if (!want && scanning) stopInternal()
        notifyListeners()
    }

    private val tick = object : Runnable {
        override fun run() {
            onTick()
            handler.postDelayed(this, 1000)
        }
    }

    private fun onTick() {
        val now = SystemClock.elapsedRealtime()
        tickN++
        if (tickN % 3 == 1) refreshBonded()
        for (d in devices.values) d.update(now)
        devices.values.removeAll { !it.saved && now - it.lastSeen > FORGET_MS }
        notifyListeners()
    }

    // ---------- dispositivi gia' in memoria ----------

    private fun friendly(b: BluetoothDevice): String? = try {
        (if (Build.VERSION.SDK_INT >= 30) b.alias else null) ?: b.name
    } catch (e: SecurityException) {
        null
    }

    private fun refreshBonded() {
        val ad = adapter() ?: return
        if (!hasConnectPerm()) return
        val bonded: Set<BluetoothDevice> = try {
            ad.bondedDevices ?: return
        } catch (e: SecurityException) {
            return
        }
        val addrs = HashSet<String>()
        for (b in bonded) {
            addrs.add(b.address)
            val d = devices.getOrPut(b.address) { Dev(b.address) }
            d.saved = true
            val nm = friendly(b)
            if (!nm.isNullOrBlank()) d.name = nm
        }
        for (d in devices.values) {
            if (d.saved && d.address !in addrs) d.saved = false
        }
    }

    // ---------- scansione ----------

    private fun startInternal() {
        val ad = adapter() ?: return
        error = null
        try {
            refreshBonded()
            val s = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
            leScanner = ad.bluetoothLeScanner
            leScanner?.startScan(null, s, leCallback)
            scanning = true
            beginDiscovery()
        } catch (e: Exception) {
            scanning = false
            error = "Ricerca non riuscita"
        }
    }

    private fun stopInternal() {
        try {
            leScanner?.stopScan(leCallback)
        } catch (e: Exception) {
        }
        try {
            adapter()?.cancelDiscovery()
        } catch (e: Exception) {
        }
        handler.removeCallbacks(discoveryRestart)
        leScanner = null
        scanning = false
    }

    private val discoveryRestart = Runnable { if (scanning) beginDiscovery() }

    /** La ricerca "classica" (cuffie, casse vecchie) dura ~12 s: la facciamo ripartire finche' si cerca. */
    private fun beginDiscovery() {
        try {
            val ad = adapter()
            if (ad != null && !ad.isDiscovering) ad.startDiscovery()
        } catch (e: Exception) {
        }
    }

    private fun onSeen(dev: BluetoothDevice, rssi: Int, advName: String?, tx: Int?) {
        if (!scanning) return
        if (rssi == 127) return // 127 = RSSI non disponibile
        val d = devices.getOrPut(dev.address) { Dev(dev.address) }
        val nm = if (!advName.isNullOrBlank()) advName else friendly(dev)
        if (!nm.isNullOrBlank()) d.name = nm
        try {
            if (dev.bondState == BluetoothDevice.BOND_BONDED) d.saved = true
        } catch (e: SecurityException) {
        }
        if (tx != null && tx != 127 && tx in -40..20) d.refRssi = tx - 41
        d.addSample(SystemClock.elapsedRealtime(), rssi)
    }

    private val leCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            onSeen(result.device, result.rssi, result.scanRecord?.deviceName, result.txPower)
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>) {
            for (r in results) onSeen(r.device, r.rssi, r.scanRecord?.deviceName, r.txPower)
        }

        override fun onScanFailed(errorCode: Int) {
            scanning = false
            error = "Ricerca non riuscita (codice $errorCode)"
            notifyListeners()
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val dev = IntentCompat.getParcelableExtra(
                        i, BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java
                    ) ?: return
                    val rssi = i.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE).toInt()
                    if (rssi == Short.MIN_VALUE.toInt()) return
                    onSeen(dev, rssi, i.getStringExtra(BluetoothDevice.EXTRA_NAME), null)
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    if (scanning) handler.postDelayed(discoveryRestart, 1500)
                }
                BluetoothAdapter.ACTION_STATE_CHANGED -> reconcile()
                BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                    refreshBonded()
                    notifyListeners()
                }
            }
        }
    }
}
