package com.vicino

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.View
import androidx.core.graphics.ColorUtils
import com.google.android.material.R as MR
import com.google.android.material.color.MaterialColors
import java.util.Locale
import kotlin.math.ln

/** Colori del tema Material (gli stessi usati da Motion Cues). */
class Colors(
    val surface: Int,
    val onSurface: Int,
    val onVariant: Int,
    val cardBg: Int,
    val primary: Int,
    val primaryContainer: Int,
    val onPrimaryContainer: Int,
    val outline: Int
)

/** Palette dell'app: freddo -> caldo, come nella stessa app Motion Cues. */
object Pal {
    val COLD: Int = Color.parseColor("#4FC3F7")
    val MID: Int = Color.parseColor("#FFC107")
    val HOT: Int = Color.parseColor("#FF7043")
    val DARK: Int = Color.parseColor("#12161C")
    val LINE: Int = Color.parseColor("#2A313B")
    val AVATARS = intArrayOf(
        Color.parseColor("#4FC3F7"),
        Color.parseColor("#FF7043"),
        Color.parseColor("#FFC107"),
        Color.parseColor("#81C784"),
        Color.parseColor("#BA68C8"),
        Color.parseColor("#F06292")
    )
}

val IT: Locale = Locale.ITALIAN
const val MAX_D = 20f

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
fun View.dp(v: Int): Int = context.dp(v)

fun Context.colors(): Colors {
    fun c(attr: Int, def: Int): Int = MaterialColors.getColor(this, attr, def)
    return Colors(
        c(MR.attr.colorSurface, Color.WHITE),
        c(MR.attr.colorOnSurface, Color.BLACK),
        c(MR.attr.colorOnSurfaceVariant, Color.DKGRAY),
        c(MR.attr.colorSurfaceContainerHigh, Color.LTGRAY),
        c(MR.attr.colorPrimary, Color.BLUE),
        c(MR.attr.colorPrimaryContainer, Color.LTGRAY),
        c(MR.attr.colorOnPrimaryContainer, Color.BLACK),
        c(MR.attr.colorOutlineVariant, Color.GRAY)
    )
}

/** Riga di lista "raggruppata" stile iOS: angoli grandi sulla prima/ultima, piccoli in mezzo. */
fun Context.rowBg(first: Boolean, last: Boolean, color: Int): GradientDrawable {
    val big = dp(24).toFloat()
    val small = dp(6).toFloat()
    val t = if (first) big else small
    val b = if (last) big else small
    val g = GradientDrawable()
    g.setColor(color)
    g.cornerRadii = floatArrayOf(t, t, t, t, b, b, b, b)
    return g
}

fun fmtMeters(d: Float): String =
    if (d < 10f) String.format(IT, "%.1f", d) else Math.round(d).toString()

/** Distanza arrotondata a mezzo metro (sotto i 10 m) o al metro, per non far "tremare" i numeri. */
fun roundDist(d: Float): Float =
    if (d < 10f) Math.round(d * 2f) / 2f else Math.round(d).toFloat()

fun fmtDistRow(d: Float): String =
    if (d < 0.5f) "meno di mezzo metro" else "circa ${fmtMeters(d)} m"

/** Da -95 dBm (debole) a -45 dBm (fortissimo) -> da 0 a 4 tacche. */
fun rssiLevel(rssi: Float?): Float =
    if (rssi == null) 0f else ((rssi + 95f) / 50f * 4f).coerceIn(0f, 4f)

/** 0 = vicinissimo, 1 = lontanissimo (scala logaritmica: i primi metri contano di piu'). */
fun distFrac(d: Float): Float = (ln(1f + d) / ln(1f + MAX_D)).coerceIn(0f, 1f)

fun heatColor(h: Float): Int {
    val x = h.coerceIn(0f, 1f)
    return if (x < 0.5f) ColorUtils.blendARGB(Pal.COLD, Pal.MID, x * 2f)
    else ColorUtils.blendARGB(Pal.MID, Pal.HOT, (x - 0.5f) * 2f)
}
