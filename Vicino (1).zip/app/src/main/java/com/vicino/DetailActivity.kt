package com.vicino

import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.R as MR
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import kotlin.math.roundToInt

/** Schermata del singolo dispositivo: radar, distanza grande che "scorre", caldo/freddo e (se c'e') la direzione UWB. */
class DetailActivity : AppCompatActivity() {

    private lateinit var addr: String
    private lateinit var col: Colors
    private lateinit var radar: RadarView
    private lateinit var number: TextView
    private lateinit var unit: TextView
    private lateinit var label: TextView
    private lateinit var pill: TextView
    private lateinit var titleView: TextView
    private lateinit var sub: TextView
    private lateinit var signal: SignalView
    private lateinit var rssiText: TextView
    private lateinit var numSpring: SpringFloat
    private lateinit var heatSpring: SpringFloat

    private val history = ArrayList<Pair<Long, Float>>()
    private var lastBucket = -1
    private var showingDash = true
    private var pillTarget = ""
    private val listener: () -> Unit = { update() }

    private fun card(content: View): MaterialCardView = MaterialCardView(this).apply {
        radius = dp(28).toFloat()
        cardElevation = 0f
        strokeWidth = 0
        setCardBackgroundColor(col.cardBg)
        addView(content)
        layoutParams = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(12) }
    }

    private fun body(text: String, color: Int): TextView = TextView(this).apply {
        setTextAppearance(MR.style.TextAppearance_Material3_BodyMedium)
        setTextColor(color)
        this.text = text
    }

    private fun pillBg(): GradientDrawable {
        val g = GradientDrawable()
        g.cornerRadius = dp(20).toFloat()
        g.setColor(col.primaryContainer)
        return g
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        overridePendingTransition(R.anim.slide_up, R.anim.stay)
        ScanHub.init(this)
        val a = intent.getStringExtra("addr")
        if (a == null) {
            finish()
            return
        }
        addr = a
        col = colors()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(32))
        }

        // maniglia in alto, come i fogli di iOS
        val grabber = View(this).apply {
            val g = GradientDrawable()
            g.cornerRadius = dp(3).toFloat()
            g.setColor(col.outline)
            background = g
        }
        root.addView(grabber, LinearLayout.LayoutParams(dp(40), dp(5)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(16)
        })

        titleView = TextView(this).apply {
            setTextAppearance(MR.style.TextAppearance_Material3_HeadlineMedium)
            setTextColor(col.onSurface)
            setPadding(dp(8), 0, dp(8), 0)
            maxLines = 2
        }
        sub = body("", col.onVariant).apply { setPadding(dp(8), dp(4), dp(8), dp(16)) }
        root.addView(titleView)
        root.addView(sub)

        // ---------- radar + distanza ----------
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(16), dp(16), dp(20))
        }
        val screen = LinearLayout(this).apply {
            val g = GradientDrawable()
            g.cornerRadius = dp(24).toFloat()
            g.setColor(Pal.DARK)
            background = g
            clipToOutline = true
        }
        radar = RadarView(this).apply {
            accent = Pal.COLD
            ringColor = Pal.LINE
        }
        screen.addView(radar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        hero.addView(screen, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(260)
        ).apply { bottomMargin = dp(12) })

        val numRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM
        }
        number = TextView(this).apply {
            setTextAppearance(MR.style.TextAppearance_Material3_DisplayLarge)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            textSize = 64f
            setTextColor(col.onVariant)
            text = "—"
            includeFontPadding = false
        }
        unit = TextView(this).apply {
            setTextAppearance(MR.style.TextAppearance_Material3_TitleLarge)
            setTextColor(col.onVariant)
            text = " m"
            setPadding(dp(4), 0, 0, dp(8))
        }
        numRow.addView(number)
        numRow.addView(unit)
        hero.addView(numRow)

        label = TextView(this).apply {
            setTextAppearance(MR.style.TextAppearance_Material3_TitleMedium)
            setTextColor(col.onSurface)
            gravity = Gravity.CENTER
            text = "Cerco il dispositivo…"
        }
        hero.addView(label, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(4) })

        pill = TextView(this).apply {
            setTextAppearance(MR.style.TextAppearance_Material3_LabelLarge)
            setPadding(dp(14), dp(6), dp(14), dp(6))
            background = pillBg()
            setTextColor(col.onPrimaryContainer)
            text = "Muoviti per capire la direzione"
        }
        pillTarget = "Muoviti per capire la direzione"
        hero.addView(pill, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) })
        val heroCard = card(hero)
        root.addView(heroCard)

        // ---------- segnale ----------
        val sig = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        val sigRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        sigRow.addView(TextView(this).apply {
            setTextAppearance(MR.style.TextAppearance_Material3_TitleMedium)
            setTextColor(col.onSurface)
            text = "Segnale"
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        rssiText = body("—", col.onVariant)
        sigRow.addView(rssiText, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { marginEnd = dp(12) })
        signal = SignalView(this).apply {
            onColor = col.primary
            offColor = col.outline
        }
        sigRow.addView(signal)
        sig.addView(sigRow)
        sig.addView(body(
            "La distanza è una stima dal segnale radio: muri, corpo e interferenze la fanno variare " +
                "anche di qualche metro. Cammina verso il dispositivo e guarda il numero scendere: " +
                "il colore passa dal freddo al caldo.",
            col.onVariant
        ).apply { setPadding(0, dp(8), 0, 0) })
        val sigCard = card(sig)
        root.addView(sigCard)

        // ---------- UWB ----------
        val hasUwb = packageManager.hasSystemFeature("android.hardware.uwb")
        val uwb = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(16))
        }
        val uwbRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        uwbRow.addView(TextView(this).apply {
            setTextAppearance(MR.style.TextAppearance_Material3_TitleMedium)
            setTextColor(col.onSurface)
            text = "Direzione (UWB)"
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        uwbRow.addView(TextView(this).apply {
            setTextAppearance(MR.style.TextAppearance_Material3_LabelLarge)
            setPadding(dp(12), dp(4), dp(12), dp(4))
            background = pillBg()
            setTextColor(col.onPrimaryContainer)
            text = if (hasUwb) "Disponibile" else "Non disponibile"
        })
        uwb.addView(uwbRow)
        uwb.addView(body(
            if (hasUwb) {
                "Il tuo telefono ha il chip UWB. La freccia di direzione compare solo con dispositivi " +
                    "UWB compatibili (tag e accessori): questo dispositivo Bluetooth non lo usa, quindi qui vedi la distanza."
            } else {
                "Questo telefono non ha il chip UWB, quindi non può indicare la direzione: vedi la distanza stimata dal segnale Bluetooth."
            },
            col.onVariant
        ).apply { setPadding(0, dp(8), 0, 0) })
        val uwbCard = card(uwb)
        root.addView(uwbCard)

        val close = MaterialButton(
            this, null, MR.attr.materialButtonOutlinedStyle
        ).apply {
            text = "Chiudi"
            cornerRadius = dp(28)
            insetTop = 0
            insetBottom = 0
            setOnClickListener { finish() }
        }
        Springs.pressable(close, 0.97f)
        root.addView(close, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(56)
        ))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(col.surface)
            isFillViewport = true
            addView(root)
        })

        // molle: numero grande e colore caldo/freddo
        numSpring = SpringFloat(0f, damp = 0.85f, stiff = 120f, minVisible = 0.02f) { v ->
            if (!showingDash) number.text = fmtMeters(v)
        }
        heatSpring = SpringFloat(0f, damp = 1f, stiff = 100f, minVisible = 0.005f) { v ->
            if (!showingDash) number.setTextColor(heatColor(v))
        }

        Springs.enter(titleView, 0, dp(24).toFloat())
        Springs.enter(sub, 40, dp(24).toFloat())
        Springs.enter(heroCard, 90, dp(48).toFloat())
        Springs.enter(sigCard, 170, dp(48).toFloat())
        Springs.enter(uwbCard, 240, dp(48).toFloat())
        Springs.enter(close, 310, dp(48).toFloat())
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.stay, R.anim.slide_down)
    }

    override fun onStart() {
        super.onStart()
        ScanHub.attach()
        ScanHub.enable(true)
        ScanHub.addListener(listener)
        update()
    }

    override fun onStop() {
        ScanHub.removeListener(listener)
        ScanHub.detach()
        super.onStop()
    }

    // ------------------------------------------------------------------

    private fun bucket(d: Float): Int = when {
        d < 0.7f -> 0
        d < 2f -> 1
        d < 5f -> 2
        d < 10f -> 3
        else -> 4
    }

    private val bucketLabels = arrayOf(
        "Vicinissimo", "Vicino", "Nella stessa stanza", "Un po' lontano", "Lontano"
    )

    private fun setPill(text: String) {
        if (text == pillTarget) return
        pillTarget = text
        pill.animate().alpha(0f).setDuration(120).withEndAction {
            pill.text = pillTarget
            pill.animate().alpha(1f).setDuration(200).start()
        }.start()
    }

    private fun update() {
        if (!::numSpring.isInitialized) return
        val d = ScanHub.devices[addr]
        val nm = d?.name
        titleView.text = if (!nm.isNullOrBlank()) nm else "Dispositivo ${addr.takeLast(5)}"
        sub.text = if (d?.saved == true) "Salvato su questo telefono" else "Dispositivo nuovo"

        val dist = d?.distance
        val live = d != null && d.inRange && dist != null

        if (live && dist != null) {
            if (showingDash) {
                showingDash = false
                numSpring.snapTo(dist)
                heatSpring.snapTo(1f - distFrac(dist))
                radar.setTarget(dist, null, true, snap = true)
            } else {
                numSpring.to(dist)
                heatSpring.to(1f - distFrac(dist))
                radar.setTarget(dist, null, true)
            }

            val now = SystemClock.elapsedRealtime()
            history.add(Pair(now, dist))
            history.removeAll { now - it.first > 6000L }
            val old = history.first().second
            val delta = dist - old
            val thr = maxOf(0.3f, 0.12f * dist)
            val trend = when {
                history.size < 3 -> 0
                delta < -thr -> -1
                delta > thr -> 1
                else -> 0
            }
            setPill(
                when (trend) {
                    -1 -> "Ti stai avvicinando"
                    1 -> "Ti stai allontanando"
                    else -> "Muoviti per capire la direzione"
                }
            )

            val b = bucket(dist)
            label.text = bucketLabels[b]
            if (lastBucket != -1 && b != lastBucket) {
                window.decorView.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            lastBucket = b

            val s = d?.smooth
            signal.setLevel(rssiLevel(s))
            rssiText.text = if (s != null) "${s.roundToInt()} dBm" else "—"
        } else {
            if (!showingDash) {
                showingDash = true
                number.text = "—"
                number.setTextColor(col.onVariant)
            }
            history.clear()
            lastBucket = -1
            radar.setTarget(dist, null, false)
            signal.setLevel(0f)
            rssiText.text = "—"
            label.text = if (d?.lastSeen == 0L || d == null) "Cerco il dispositivo…" else "Segnale perso"
            setPill(
                when {
                    !ScanHub.btOn() -> "Bluetooth spento"
                    !ScanHub.scanning -> "Ricerca ferma"
                    else -> "Avvicinati o aspetta un momento"
                }
            )
        }
    }
}
