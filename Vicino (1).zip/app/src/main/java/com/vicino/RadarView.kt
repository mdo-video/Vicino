package com.vicino

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Radar: tu sei al centro, il dispositivo e' un pallino la cui distanza dal centro segue
 * la distanza stimata (con molla). Se si conosce la direzione (UWB) il pallino ruota di conseguenza.
 * In modalita' "pulsing" mostra le onde che si espandono (ricerca in corso).
 */
class RadarView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    var accent: Int = Pal.COLD
    var ringColor: Int = Color.GRAY

    var pulsing: Boolean = false
        set(value) {
            field = value
            updateAnim()
        }

    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0f
    private var animator: ValueAnimator? = null

    private val frac = SpringFloat(0.5f, damp = 0.7f, stiff = 110f, minVisible = 0.002f) { invalidate() }
    private val angle = SpringFloat(-90f, damp = 0.8f, stiff = 90f, minVisible = 0.2f) { invalidate() }
    private val shown = SpringFloat(0f, damp = 1f, stiff = 140f, minVisible = 0.005f) { invalidate() }
    private val heat = SpringFloat(0f, damp = 1f, stiff = 100f, minVisible = 0.005f) { invalidate() }

    /**
     * distance = null: nasconde il bersaglio.
     * live = false: il segnale e' perso, il pallino resta ma sbiadito.
     * bearingDeg = direzione in gradi (0 = davanti a te), solo se disponibile (UWB).
     */
    fun setTarget(distance: Float?, bearingDeg: Float?, live: Boolean, snap: Boolean = false) {
        if (distance == null) {
            shown.to(0f)
            return
        }
        val f = distFrac(distance)
        val a = if (bearingDeg != null) bearingDeg - 90f else -90f
        val vis = if (live) 1f else 0.35f
        if (snap) {
            frac.snapTo(f)
            heat.snapTo(1f - f)
            angle.snapTo(a)
            shown.snapTo(vis)
        } else {
            frac.to(f)
            heat.to(1f - f)
            angle.to(a)
            shown.to(vis)
        }
    }

    private fun updateAnim() {
        if (pulsing && isAttachedToWindow) {
            if (animator == null) {
                val va = ValueAnimator.ofFloat(0f, 1f)
                va.duration = 2600
                va.repeatCount = ValueAnimator.INFINITE
                va.interpolator = LinearInterpolator()
                va.addUpdateListener {
                    phase = it.animatedValue as Float
                    invalidate()
                }
                animator = va
            }
            if (animator?.isStarted != true) animator?.start()
        } else {
            animator?.cancel()
            animator = null
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        updateAnim()
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val maxR = min(width, height) / 2f - 6 * density
        val minR = 30 * density

        // anelli fissi
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f * density
        paint.color = ringColor
        for (k in 1..3) {
            paint.alpha = 90 - k * 18
            c.drawCircle(cx, cy, minR + (maxR - minR) * k / 3f, paint)
        }

        // onde della ricerca
        if (pulsing) {
            paint.color = accent
            for (k in 0..1) {
                val p = (phase + k * 0.5f) % 1f
                paint.alpha = ((1f - p) * 120f).toInt()
                c.drawCircle(cx, cy, 14 * density + p * (maxR - 14 * density), paint)
            }
        }

        // tu, al centro
        paint.style = Paint.Style.FILL
        paint.color = accent
        paint.alpha = 50
        c.drawCircle(cx, cy, 15 * density, paint)
        paint.alpha = 255
        c.drawCircle(cx, cy, 7 * density, paint)

        // il dispositivo
        val a = shown.value
        if (a > 0.01f) {
            val r = minR + frac.value.coerceIn(0f, 1f) * (maxR - minR)
            val rad = Math.toRadians(angle.value.toDouble())
            val x = cx + (r * cos(rad)).toFloat()
            val y = cy + (r * sin(rad)).toFloat()
            val col = heatColor(heat.value)

            paint.style = Paint.Style.STROKE
            paint.color = col
            paint.alpha = (a * 70).toInt()
            c.drawCircle(cx, cy, r, paint)

            paint.style = Paint.Style.FILL
            paint.color = col
            paint.alpha = (a * 60).toInt()
            c.drawCircle(x, y, 20 * density, paint)
            paint.alpha = (a * 255).toInt()
            c.drawCircle(x, y, 9 * density, paint)
            paint.color = Color.WHITE
            paint.alpha = (a * 230).toInt()
            c.drawCircle(x, y, 3 * density, paint)
        }
    }
}
