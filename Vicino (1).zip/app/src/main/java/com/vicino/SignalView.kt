package com.vicino

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import androidx.core.graphics.ColorUtils

/** Quattro tacche di segnale che si riempiono con una molla (valore da 0 a 4, anche frazionario). */
class SignalView(ctx: Context) : View(ctx) {

    var onColor: Int = Pal.COLD
    var offColor: Int = Pal.LINE

    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val level = SpringFloat(0f, damp = 0.8f, stiff = 200f, minVisible = 0.01f) { invalidate() }

    fun setLevel(l: Float) {
        level.to(l)
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension((25 * density).toInt(), (18 * density).toInt())
    }

    override fun onDraw(canvas: Canvas) {
        val bw = 4 * density
        val gap = 3 * density
        val maxH = height.toFloat()
        for (i in 0 until 4) {
            val h = maxH * (0.35f + 0.65f * i / 3f)
            val x = i * (bw + gap)
            val on = (level.value - i).coerceIn(0f, 1f)
            paint.color = ColorUtils.blendARGB(offColor, onColor, on)
            canvas.drawRoundRect(x, height - h, x + bw, height.toFloat(), bw / 2f, bw / 2f, paint)
        }
    }
}
