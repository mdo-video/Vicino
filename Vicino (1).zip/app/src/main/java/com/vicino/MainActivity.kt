package com.vicino

import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SimpleItemAnimator
import com.google.android.material.R as MR
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.materialswitch.MaterialSwitch

/** Le righe della schermata principale (una sola lista che scorre, come le impostazioni di iOS). */
sealed class Row {
    abstract val key: String

    data class Hero(
        val scanning: Boolean,
        val enabled: Boolean,
        val btOn: Boolean,
        val hasPerm: Boolean,
        val error: String?,
        val hideUnnamed: Boolean,
        val found: Int
    ) : Row() {
        override val key: String get() = "hero"
    }

    data class Title(val text: String, val count: Int) : Row() {
        override val key: String get() = "title:$text"
    }

    data class Item(
        val address: String,
        val name: String,
        val inRange: Boolean,
        val rssi: Float?,
        val distance: Float?,
        val first: Boolean,
        val last: Boolean
    ) : Row() {
        override val key: String get() = "dev:$address"
    }

    data class Empty(val id: String, val text: String) : Row() {
        override val key: String get() = "empty:$id"
    }
}

object RowDiff : DiffUtil.ItemCallback<Row>() {
    override fun areItemsTheSame(a: Row, b: Row): Boolean = a.key == b.key
    override fun areContentsTheSame(a: Row, b: Row): Boolean = a == b
}

interface RowHost {
    fun onMain()
    fun onFilter(hideUnnamed: Boolean)
    fun onOpen(address: String)
}

class HeroVH(
    val root: LinearLayout,
    val card: View,
    val pill: TextView,
    val radar: RadarView,
    val button: MaterialButton,
    val filter: MaterialSwitch
) : RecyclerView.ViewHolder(root) {
    var suppress = false
}

class TitleVH(val tv: TextView) : RecyclerView.ViewHolder(tv)
class EmptyVH(val tv: TextView) : RecyclerView.ViewHolder(tv)

class DevVH(
    val root: LinearLayout,
    val avatar: TextView,
    val avatarBg: GradientDrawable,
    val name: TextView,
    val sub: TextView,
    val signal: SignalView
) : RecyclerView.ViewHolder(root) {
    var address = ""
}

class DeviceAdapter(
    private val host: RowHost,
    private val col: Colors
) : ListAdapter<Row, RecyclerView.ViewHolder>(RowDiff) {

    private var heroEntered = false

    override fun getItemViewType(position: Int): Int = when (getItem(position)) {
        is Row.Hero -> 0
        is Row.Title -> 1
        is Row.Item -> 2
        else -> 3
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val ctx = parent.context
        return when (viewType) {
            0 -> buildHero(ctx)
            1 -> TitleVH(TextView(ctx).apply {
                setTextAppearance(MR.style.TextAppearance_Material3_LabelLarge)
                setTextColor(col.onVariant)
                letterSpacing = 0.05f
                setPadding(ctx.dp(16), ctx.dp(22), ctx.dp(16), ctx.dp(8))
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            })
            2 -> buildDevice(ctx)
            else -> EmptyVH(TextView(ctx).apply {
                setTextAppearance(MR.style.TextAppearance_Material3_BodyMedium)
                setTextColor(col.onVariant)
                setPadding(ctx.dp(20), ctx.dp(20), ctx.dp(20), ctx.dp(20))
                background = ctx.rowBg(true, true, col.cardBg)
                layoutParams = RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            })
        }
    }

    private fun buildHero(ctx: Context): HeroVH {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        val title = TextView(ctx).apply {
            setTextAppearance(MR.style.TextAppearance_Material3_HeadlineLarge)
            setTextColor(col.onSurface)
            text = "Vicino"
            setPadding(ctx.dp(8), 0, ctx.dp(8), 0)
        }
        val subtitle = TextView(ctx).apply {
            setTextAppearance(MR.style.TextAppearance_Material3_BodyMedium)
            setTextColor(col.onVariant)
            text = "Trova i tuoi dispositivi Bluetooth e scopri quanto sono lontani."
            setPadding(ctx.dp(8), ctx.dp(4), ctx.dp(8), ctx.dp(16))
        }
        root.addView(title)
        root.addView(subtitle)

        val inner = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.dp(16), ctx.dp(16), ctx.dp(16), ctx.dp(8))
        }
        val pill = TextView(ctx).apply {
            setTextAppearance(MR.style.TextAppearance_Material3_LabelLarge)
            setPadding(ctx.dp(14), ctx.dp(6), ctx.dp(14), ctx.dp(6))
            val g = GradientDrawable()
            g.cornerRadius = ctx.dp(20).toFloat()
            g.setColor(col.primaryContainer)
            background = g
            setTextColor(col.onPrimaryContainer)
        }
        inner.addView(pill, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = ctx.dp(4) })

        // finto schermo scuro, come nell'anteprima di Motion Cues
        val screen = LinearLayout(ctx).apply {
            val g = GradientDrawable()
            g.cornerRadius = ctx.dp(24).toFloat()
            g.setColor(Pal.DARK)
            background = g
            clipToOutline = true
        }
        val radar = RadarView(ctx).apply {
            accent = Pal.COLD
            ringColor = Pal.LINE
        }
        screen.addView(radar, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
        ))
        inner.addView(screen, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ctx.dp(180)
        ).apply { bottomMargin = ctx.dp(16) })

        val button = MaterialButton(ctx).apply {
            textSize = 16f
            cornerRadius = ctx.dp(28)
            insetTop = 0
            insetBottom = 0
        }
        inner.addView(button, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ctx.dp(56)
        ))
        Springs.pressable(button, 0.97f)

        val filterRow = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ctx.dp(4), ctx.dp(8), ctx.dp(4), 0)
        }
        filterRow.addView(TextView(ctx).apply {
            setTextAppearance(MR.style.TextAppearance_Material3_BodyMedium)
            setTextColor(col.onVariant)
            text = "Nascondi i dispositivi senza nome"
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val filter = MaterialSwitch(ctx)
        filterRow.addView(filter)
        inner.addView(filterRow)

        val card = MaterialCardView(ctx).apply {
            radius = ctx.dp(28).toFloat()
            cardElevation = 0f
            strokeWidth = 0
            setCardBackgroundColor(col.cardBg)
            addView(inner)
        }
        root.addView(card, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        val h = HeroVH(root, card, pill, radar, button, filter)
        button.setOnClickListener { host.onMain() }
        filter.setOnCheckedChangeListener { _, on ->
            if (!h.suppress) host.onFilter(on)
        }
        if (!heroEntered) {
            heroEntered = true
            Springs.enter(title, 0, ctx.dp(24).toFloat())
            Springs.enter(subtitle, 60, ctx.dp(24).toFloat())
            Springs.enter(card, 120, ctx.dp(40).toFloat())
        }
        return h
    }

    private fun buildDevice(ctx: Context): DevVH {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ctx.dp(16), ctx.dp(12), ctx.dp(16), ctx.dp(12))
            minimumHeight = ctx.dp(72)
            isClickable = true
            isFocusable = true
            layoutParams = RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = ctx.dp(2) }
        }
        val avatarBg = GradientDrawable()
        avatarBg.shape = GradientDrawable.OVAL
        val avatar = TextView(ctx).apply {
            gravity = Gravity.CENTER
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Pal.DARK)
            background = avatarBg
        }
        root.addView(avatar, LinearLayout.LayoutParams(ctx.dp(44), ctx.dp(44)).apply {
            marginEnd = ctx.dp(14)
        })
        val texts = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val name = TextView(ctx).apply {
            setTextAppearance(MR.style.TextAppearance_Material3_TitleMedium)
            setTextColor(col.onSurface)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        val sub = TextView(ctx).apply {
            setTextAppearance(MR.style.TextAppearance_Material3_BodyMedium)
            setTextColor(col.onVariant)
            maxLines = 1
        }
        texts.addView(name)
        texts.addView(sub)
        root.addView(texts, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val signal = SignalView(ctx).apply {
            onColor = col.primary
            offColor = col.outline
        }
        root.addView(signal, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { marginStart = ctx.dp(12) })

        val h = DevVH(root, avatar, avatarBg, name, sub, signal)
        root.setOnClickListener { host.onOpen(h.address) }
        Springs.pressable(root, 0.97f)
        return h
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (val r = getItem(position)) {
            is Row.Hero -> bindHero(holder as HeroVH, r)
            is Row.Title -> {
                (holder as TitleVH).tv.text = "${r.text.uppercase(IT)} · ${r.count}"
            }
            is Row.Item -> bindItem(holder as DevVH, r)
            is Row.Empty -> {
                (holder as EmptyVH).tv.text = r.text
            }
        }
    }

    private fun bindHero(h: HeroVH, r: Row.Hero) {
        val pillText = when {
            !r.hasPerm -> "Serve il permesso Bluetooth"
            !r.btOn -> "Bluetooth spento"
            r.error != null -> r.error
            r.scanning -> "● Ricerca in corso · ${r.found} vicini"
            else -> "Ricerca ferma"
        }
        h.pill.text = pillText
        val btn = when {
            !r.hasPerm -> "Consenti il Bluetooth"
            !r.btOn -> "Accendi il Bluetooth"
            r.enabled -> "Ferma la ricerca"
            else -> "Cerca dispositivi"
        }
        if (h.button.text.toString() != btn) {
            h.button.text = btn
            if (h.button.tag != null) Springs.pop(h.button)
            h.button.tag = true
        }
        h.radar.pulsing = r.scanning
        h.suppress = true
        h.filter.isChecked = r.hideUnnamed
        h.suppress = false
    }

    private fun bindItem(h: DevVH, r: Row.Item) {
        val ctx = h.root.context
        h.address = r.address
        h.name.text = r.name
        h.sub.text = when {
            r.inRange && r.distance != null -> fmtDistRow(r.distance)
            else -> "Non rilevato"
        }
        val letter = r.name.firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "•"
        h.avatar.text = letter
        val idx = (r.name.hashCode() and 0x7fffffff) % Pal.AVATARS.size
        h.avatarBg.setColor(Pal.AVATARS[idx])
        h.avatar.alpha = if (r.inRange) 1f else 0.4f
        h.name.alpha = if (r.inRange) 1f else 0.6f
        h.signal.setLevel(if (r.inRange) rssiLevel(r.rssi) else 0f)
        h.root.background = ctx.rowBg(r.first, r.last, col.cardBg)
    }
}

class MainActivity : AppCompatActivity(), RowHost {

    private lateinit var listAdapter: DeviceAdapter
    private var hideUnnamed = true
    private val listener: () -> Unit = { rebuild() }

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (ScanHub.hasScanPerm()) ScanHub.enable(true)
        ScanHub.reconcile()
        rebuild()
    }

    private val btLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (ScanHub.btOn()) ScanHub.enable(true)
        ScanHub.reconcile()
        rebuild()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ScanHub.init(this)
        val col = colors()

        listAdapter = DeviceAdapter(this, col)
        val list = RecyclerView(this).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            clipToPadding = false
            setPadding(dp(16), dp(24), dp(16), dp(32))
            setBackgroundColor(col.surface)
            adapter = listAdapter
            (itemAnimator as? SimpleItemAnimator)?.supportsChangeAnimations = false
            itemAnimator?.addDuration = 320
            itemAnimator?.moveDuration = 380
            itemAnimator?.removeDuration = 220
        }
        setContentView(list)

        if (savedInstanceState == null) {
            if (ScanHub.hasScanPerm()) ScanHub.enable(true)
            else permLauncher.launch(ScanHub.requiredPermissions())
        }
    }

    override fun onStart() {
        super.onStart()
        ScanHub.attach()
        ScanHub.addListener(listener)
        rebuild()
    }

    override fun onStop() {
        ScanHub.removeListener(listener)
        ScanHub.detach()
        super.onStop()
    }

    // ---------- RowHost ----------

    override fun onMain() {
        when {
            !ScanHub.hasScanPerm() -> permLauncher.launch(ScanHub.requiredPermissions())
            !ScanHub.btOn() -> btLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
            ScanHub.enabled -> ScanHub.enable(false)
            else -> ScanHub.enable(true)
        }
        rebuild()
    }

    override fun onFilter(hideUnnamed: Boolean) {
        this.hideUnnamed = hideUnnamed
        rebuild()
    }

    override fun onOpen(address: String) {
        startActivity(Intent(this, DetailActivity::class.java).putExtra("addr", address))
    }

    // ---------- costruzione delle righe ----------

    private fun nameOf(d: Dev): String {
        val n = d.name
        return if (!n.isNullOrBlank()) n else "Dispositivo ${d.address.takeLast(5)}"
    }

    private fun toItems(list: List<Dev>): List<Row> {
        return list.mapIndexed { i, d ->
            Row.Item(
                address = d.address,
                name = nameOf(d),
                inRange = d.inRange,
                // arrotondiamo per non ridisegnare la riga a ogni minima variazione
                rssi = if (d.inRange) d.smooth?.let { Math.round(it / 3f) * 3f } else null,
                distance = if (d.inRange) d.distance?.let { roundDist(it) } else null,
                first = i == 0,
                last = i == list.size - 1
            )
        }
    }

    private fun rebuild() {
        val all = ScanHub.devices.values
        val saved = all.filter { it.saved }.sortedWith(
            compareBy<Dev>({ !it.inRange }, { it.distance?.let { d -> roundDist(d) } ?: 999f }, { nameOf(it).lowercase() })
        )
        val nearby = all
            .filter { !it.saved && it.inRange && (!hideUnnamed || !it.name.isNullOrBlank()) }
            .sortedWith(compareBy<Dev>({ it.distance?.let { d -> roundDist(d) } ?: 999f }, { nameOf(it).lowercase() }))
            .take(40)

        val hasPerm = ScanHub.hasScanPerm()
        val rows = ArrayList<Row>()
        rows.add(
            Row.Hero(
                scanning = ScanHub.scanning,
                enabled = ScanHub.enabled,
                btOn = ScanHub.btOn(),
                hasPerm = hasPerm,
                error = ScanHub.error,
                hideUnnamed = hideUnnamed,
                found = all.count { it.inRange }
            )
        )

        rows.add(Row.Title("Dispositivi salvati", saved.size))
        if (saved.isEmpty()) {
            rows.add(
                Row.Empty(
                    "saved",
                    if (!hasPerm) "Consenti il Bluetooth per vedere i dispositivi già associati al telefono."
                    else "Nessun dispositivo associato a questo telefono."
                )
            )
        } else {
            rows.addAll(toItems(saved))
        }

        rows.add(Row.Title("Nuovi dispositivi", nearby.size))
        if (nearby.isEmpty()) {
            rows.add(
                Row.Empty(
                    "new",
                    if (ScanHub.scanning) "Cerco intorno a te…" else "Avvia la ricerca per trovare i dispositivi vicini."
                )
            )
        } else {
            rows.addAll(toItems(nearby))
        }
        listAdapter.submitList(rows)
    }
}
