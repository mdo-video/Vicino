# Vicino (Android)

Trova i dispositivi Bluetooth intorno a te e scopri quanto sono distanti.

- Due liste: **Dispositivi salvati** (gia' associati al telefono) e **Nuovi dispositivi** (non in memoria).
- Tocca un dispositivo: radar animato, distanza che si aggiorna in tempo reale, caldo/freddo, tacche di segnale.
- Direzione con UWB solo se il telefono ha il chip e il dispositivo e' UWB compatibile.
- Stesso look di Motion Cues (Material 3, schede arrotondate, animazioni a molla stile iPhone).

La distanza e' una stima dal segnale radio (RSSI): in ambienti chiusi puo' variare di qualche metro.
APK firmato con chiave fissa (`app/vicino.p12`): gli aggiornamenti si installano sopra la versione precedente.
