package com.vicino

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import java.util.UUID

/** Un dispositivo Bluetooth visto (o associato) con il suo segnale filtrato. */
class Dev(val address: String) {
    var name: String? = null
    var saved: Boolean = false
    var lastSeen: Long = 0L
    var smooth: Float? = null
    var distance: Float? = null
    var inRange: Boolean = false

    /** Batteria in % (null = non nota). Stato lettura: 0 mai provata, 1 in corso, 2 letta, 3 non disponibile. */
    var battery: Int? = null
    var batteryState: Int = 0
    var batteryTriedAt: Long = 0L

    /** Segnale (dBm) misurato a 1 metro: se il dispositivo dichiara la potenza lo ricaviamo, altrimenti valore tipico. */
    var refRssi: Int = DEFAULT_REF

    private val samples = ArrayList<LongArray>() // [istante, rssi]

    fun addSample(t: Long, rssi: Int) {
        samples.add(longArrayOf(t, rssi.toLong()))
        lastSeen = t
        if (samples.size > 40) samples.removeAt(0)
    }

    /** Mediana degli ultimi secondi + media mobile: il segnale radio e' molto "rumoroso". */
    fun update(now: Long) {
        samples.removeAll { now - it[0] > WINDOW_MS }
        inRange = lastSeen != 0L && now - lastSeen < LOST_MS
        if (samples.isNotEmpty()) {
            val sorted = samples.map { it[1] }.sorted()
            val med = sorted[sorted.size / 2].toFloat()
            val prev = smooth
            smooth = if (prev == null) med else prev + 0.35f * (med - prev)
        }
        val s = smooth
        if (s != null) distance = rssiToDistance(s, refRssi)
    }

    companion object {
        const val DEFAULT_REF = -59
        const val WINDOW_MS = 6000L
        const val LOST_MS = 10000L

        /** Modello "path loss": d = 10^((rssi@1m - rssi) / (10 * n)), con n = 2,4 (ambienti chiusi). */
        fun rssiToDistance(rssi: Float, ref: Int): Float {
            val d = Math.pow(10.0, (ref - rssi) / (10.0 * 2.4))
            return d.toFloat().coerceIn(0.1f, 40f)
        }
    }
}

/**
 * Cuore dell'app: scansione Bluetooth (BLE + classico) condivisa tra le schermate.
 * Tutto gira sul thread principale (le callback del Bluetooth arrivano li').
 */
@SuppressLint("MissingPermission")
object ScanHub {

    private const val FORGET_MS = 30000L
    private const val RETRY_BATTERY_MS = 60000L
    private const val GATT_TIMEOUT_MS = 10000L
    private val BATTERY_SERVICE: UUID = UUID.fromString("0000180f-0000-1000-8000-00805f9b34fb")
    private val BATTERY_LEVEL: UUID = UUID.fromString("00002a19-0000-1000-8000-00805f9b34fb")

    val devices = LinkedHashMap<String, Dev>()

    var scanning: Boolean = false
        private set
    var enabled: Boolean = false
        private set
    var error: String? = null
        private set

    private var appCtx: Context? = null
    private var attached = 0
    private var tickN = 0
    private var leScanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private var gattAddr: String? = null
    private val handler = Handler(Looper.getMainLooper())
    private val listeners = ArrayList<() -> Unit>()

    fun init(ctx: Context) {
        if (appCtx != null) return
        val app = ctx.applicationContext
        appCtx = app
        val f = IntentFilter()
        f.addAction(BluetoothDevice.ACTION_FOUND)
        f.addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        f.addAction(BluetoothAdapter.ACTION_STATE_CHANGED)
        f.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
        ContextCompat.registerReceiver(app, receiver, f, ContextCompat.RECEIVER_EXPORTED)
    }

    // ---------- permessi e stato del Bluetooth ----------

    fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31) {
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        }

    fun hasScanPerm(): Boolean {
        val app = appCtx ?: return false
        return requiredPermissions().all {
            ContextCompat.checkSelfPermission(app, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    private fun hasConnectPerm(): Boolean {
        val app = appCtx ?: return false
        return Build.VERSION.SDK_INT < 31 ||
            ContextCompat.checkSelfPermission(app, Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun adapter(): BluetoothAdapter? =
        (appCtx?.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    fun btOn(): Boolean = try {
        adapter()?.isEnabled == true
    } catch (e: SecurityException) {
        false
    }

    // ---------- ascoltatori e ciclo di vita ----------

    fun addListener(l: () -> Unit) {
        if (!listeners.contains(l)) listeners.add(l)
    }

    fun removeListener(l: () -> Unit) {
        listeners.remove(l)
    }

    private fun notifyListeners() {
        for (l in ArrayList(listeners)) l()
    }

    /** Ogni schermata visibile chiama attach() in onStart e detach() in onStop. */
    fun attach() {
        attached++
        reconcile()
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    fun detach() {
        attached = (attached - 1).coerceAtLeast(0)
        reconcile()
        if (attached == 0) handler.removeCallbacks(tick)
    }

    /** Volonta' dell'utente: cerca / ferma. */
    fun enable(on: Boolean) {
        enabled = on
        reconcile()
    }

    /** La ricerca gira solo se: l'utente la vuole, c'e' una schermata visibile, ci sono i permessi e il Bluetooth e' acceso. */
    fun reconcile() {
        val want = enabled && attached > 0 && hasScanPerm() && btOn()
        if (want && !scanning) startInternal() else if (!want && scanning) stopInternal()
        notifyListeners()
    }

    private val tick = object : Runnable {
        override fun run() {
            onTick()
            handler.postDelayed(this, 1000)
        }
    }

    private fun onTick() {
        val now = SystemClock.elapsedRealtime()
        tickN++
        if (tickN % 3 == 1) refreshBonded()
        if (tickN % 3 == 2) refreshBatteries()
        for (d in devices.values) d.update(now)
        devices.values.removeAll { !it.saved && now - it.lastSeen > FORGET_MS }
        notifyListeners()
    }

    // ---------- dispositivi gia' in memoria ----------

    private fun friendly(b: BluetoothDevice): String? = try {
        (if (Build.VERSION.SDK_INT >= 30) b.alias else null) ?: b.name
    } catch (e: SecurityException) {
        null
    }

    private fun refreshBonded() {
        val ad = adapter() ?: return
        if (!hasConnectPerm()) return
        val bonded: Set<BluetoothDevice> = try {
            ad.bondedDevices ?: return
        } catch (e: SecurityException) {
            return
        }
        val addrs = HashSet<String>()
        for (b in bonded) {
            addrs.add(b.address)
            val d = devices.getOrPut(b.address) { Dev(b.address) }
            d.saved = true
            val nm = friendly(b)
            if (!nm.isNullOrBlank()) d.name = nm
        }
        for (d in devices.values) {
            if (d.saved && d.address !in addrs) d.saved = false
        }
    }


    // ---------- batteria ----------

    /** Batteria nota ad Android per i dispositivi collegati (cuffie, auricolari, orologi). Non e' un'API ufficiale: se manca torna null. */
    private fun systemBattery(addr: String): Int? {
        val ad = adapter() ?: return null
        if (!hasConnectPerm()) return null
        return try {
            val dev = ad.getRemoteDevice(addr)
            val m = BluetoothDevice::class.java.getMethod("getBatteryLevel")
            val v = m.invoke(dev) as? Int
            if (v != null && v in 0..100) v else null
        } catch (e: Throwable) {
            null
        }
    }

    private fun refreshBatteries() {
        for (d in devices.values) {
            if (!d.saved && !d.inRange) continue
            val b = systemBattery(d.address) ?: continue
            d.battery = b
            d.batteryState = 2
        }
    }

    /**
     * Chiede la batteria di un dispositivo: prima il dato di sistema, poi (se il dispositivo e' nel raggio)
     * una connessione veloce al servizio batteria standard del Bluetooth LE. Una lettura alla volta.
     */
    fun requestBattery(addr: String) {
        val d = devices[addr] ?: return
        if (d.battery != null || d.batteryState == 1) return
        val now = SystemClock.elapsedRealtime()
        if (d.batteryState == 3 && now - d.batteryTriedAt < RETRY_BATTERY_MS) return
        val sys = systemBattery(addr)
        if (sys != null) {
            d.battery = sys
            d.batteryState = 2
            return
        }
        if (!d.inRange || gatt != null || !hasConnectPerm()) return
        val ad = adapter() ?: return
        val ctx = appCtx ?: return
        d.batteryState = 1
        d.batteryTriedAt = now
        gattAddr = addr
        try {
            val dev = ad.getRemoteDevice(addr)
            gatt = dev.connectGatt(ctx, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
            handler.postDelayed(gattTimeout, GATT_TIMEOUT_MS)
        } catch (e: Exception) {
            finishGatt(null)
        }
    }

    private val gattTimeout = Runnable { if (gatt != null) finishGatt(null) }

    private fun finishGatt(level: Int?) {
        handler.removeCallbacks(gattTimeout)
        val a = gattAddr
        val g = gatt
        gatt = null
        gattAddr = null
        try {
            g?.disconnect()
        } catch (e: Exception) {
        }
        try {
            g?.close()
        } catch (e: Exception) {
        }
        val d = if (a != null) devices[a] else null
        if (d != null) {
            if (level != null) {
                d.battery = level
                d.batteryState = 2
            } else if (d.battery == null) {
                d.batteryState = 3
            }
            d.batteryTriedAt = SystemClock.elapsedRealtime()
        }
        notifyListeners()
    }

    private fun handleRead(g: BluetoothGatt, status: Int, v: ByteArray?) {
        handler.post {
            if (g !== gatt) return@post
            val lvl = if (status == BluetoothGatt.GATT_SUCCESS && v != null && v.isNotEmpty()) {
                v[0].toInt() and 0xFF
            } else {
                -1
            }
            finishGatt(if (lvl in 0..100) lvl else null)
        }
    }

    // Le callback GATT arrivano su un altro thread: rimandiamo tutto sul principale.
    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            handler.post {
                if (g !== gatt) return@post
                if (status != BluetoothGatt.GATT_SUCCESS || newState == BluetoothProfile.STATE_DISCONNECTED) {
                    finishGatt(null)
                } else if (newState == BluetoothProfile.STATE_CONNECTED) {
                    try {
                        if (!g.discoverServices()) finishGatt(null)
                    } catch (e: Exception) {
                        finishGatt(null)
                    }
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            handler.post {
                if (g !== gatt) return@post
                val ch = g.getService(BATTERY_SERVICE)?.getCharacteristic(BATTERY_LEVEL)
                if (status != BluetoothGatt.GATT_SUCCESS || ch == null) {
                    finishGatt(null)
                    return@post
                }
                try {
                    if (!g.readCharacteristic(ch)) finishGatt(null)
                } catch (e: Exception) {
                    finishGatt(null)
                }
            }
        }

        @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
        override fun onCharacteristicRead(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            handleRead(g, status, c.value)
        }

        override fun onCharacteristicRead(
            g: BluetoothGatt, c: BluetoothGattCharacteristic, value: ByteArray, status: Int
        ) {
            handleRead(g, status, value)
        }
    }

    // ---------- scansione ----------

    private fun startInternal() {
        val ad = adapter() ?: return
        error = null
        try {
            refreshBonded()
            val s = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
            leScanner = ad.bluetoothLeScanner
            leScanner?.startScan(null, s, leCallback)
            scanning = true
            beginDiscovery()
        } catch (e: Exception) {
            scanning = false
            error = "Ricerca non riuscita"
        }
    }

    private fun stopInternal() {
        if (gatt != null) finishGatt(null)
        try {
            leScanner?.stopScan(leCallback)
        } catch (e: Exception) {
        }
        try {
            adapter()?.cancelDiscovery()
        } catch (e: Exception) {
        }
        handler.removeCallbacks(discoveryRestart)
        leScanner = null
        scanning = false
    }

    private val discoveryRestart = Runnable { if (scanning) beginDiscovery() }

    /** La ricerca "classica" (cuffie, casse vecchie) dura ~12 s: la facciamo ripartire finche' si cerca. */
    private fun beginDiscovery() {
        try {
            val ad = adapter()
            if (ad != null && !ad.isDiscovering) ad.startDiscovery()
        } catch (e: Exception) {
        }
    }

    private fun onSeen(dev: BluetoothDevice, rssi: Int, advName: String?, tx: Int?) {
        if (!scanning) return
        if (rssi == 127) return // 127 = RSSI non disponibile
        val d = devices.getOrPut(dev.address) { Dev(dev.address) }
        val nm = if (!advName.isNullOrBlank()) advName else friendly(dev)
        if (!nm.isNullOrBlank()) d.name = nm
        try {
            if (dev.bondState == BluetoothDevice.BOND_BONDED) d.saved = true
        } catch (e: SecurityException) {
        }
        if (tx != null && tx != 127 && tx in -40..20) d.refRssi = tx - 41
        d.addSample(SystemClock.elapsedRealtime(), rssi)
    }

    private val leCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            onSeen(result.device, result.rssi, result.scanRecord?.deviceName, result.txPower)
        }

        override fun onBatchScanResults(results: MutableList<ScanResult>) {
            for (r in results) onSeen(r.device, r.rssi, r.scanRecord?.deviceName, r.txPower)
        }

        override fun onScanFailed(errorCode: Int) {
            scanning = false
            error = "Ricerca non riuscita (codice $errorCode)"
            notifyListeners()
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val dev = IntentCompat.getParcelableExtra(
                        i, BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java
                    ) ?: return
                    val rssi = i.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE).toInt()
                    if (rssi == Short.MIN_VALUE.toInt()) return
                    onSeen(dev, rssi, i.getStringExtra(BluetoothDevice.EXTRA_NAME), null)
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    if (scanning) handler.postDelayed(discoveryRestart, 1500)
                }
                BluetoothAdapter.ACTION_STATE_CHANGED -> reconcile()
                BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                    refreshBonded()
                    notifyListeners()
                }
            }
        }
    }
}
